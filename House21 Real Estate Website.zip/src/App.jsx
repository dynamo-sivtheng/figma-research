import React from 'react'
import Header from './components/Header'
import HeroSection from './components/HeroSection'
import NavigationBar from './components/NavigationBar'
import PropertyCategories from './components/PropertyCategories'
import PropertyListings from './components/PropertyListings'
import EventSection from './components/EventSection'
import LineSection from './components/LineSection'
import SellSection from './components/SellSection'
import OwnerSection from './components/OwnerSection'
import KnowledgeSection from './components/KnowledgeSection'
import NewsSection from './components/NewsSection'
import BlogSection from './components/BlogSection'
import AboutSection from './components/AboutSection'
import ContactSection from './components/ContactSection'
import Footer from './components/Footer'

function App() {
  return (
    <div className="App">
      <Header />
      <main className="main-content">
        <HeroSection />
        <NavigationBar />
        <PropertyCategories />
        <PropertyListings />
        <EventSection />
        <LineSection />
        <SellSection />
        <OwnerSection />
        <KnowledgeSection />
        <NewsSection />
        <BlogSection />
        <AboutSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  )
}

export default App
