import React from 'react'

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div style={{ textAlign: 'center', marginBottom: '40px' }}>
          <div style={{ backgroundColor: '#FFFFFF', borderRadius: '35px', padding: '20px', display: 'inline-block', marginBottom: '40px' }}>
            <img 
              src="https://static.codia.ai/image/2026-01-14/8MP5GcRQm2.png" 
              alt="ハウストゥエンティーワン ロゴ" 
              style={{ width: '118px', height: '118px', borderRadius: '20px' }}
            />
          </div>
        </div>
        
        <h2 className="footer-title">ハウストゥエンティーワン</h2>
        
        <div className="footer-offices">
          <div className="footer-office">
            <img 
              src="https://static.codia.ai/image/2026-01-14/crPKxqfEy3.png" 
              alt="本店" 
              className="footer-office-image"
            />
            <h3 className="footer-office-name">本店</h3>
            <p className="footer-office-address">
              埼玉県三郷市早稲田1-17-6<br />
              JR武蔵野線「三郷」駅より徒歩約5分
            </p>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
              <div style={{ width: '20px', height: '20px', backgroundColor: '#00A73C', borderRadius: '2px' }}></div>
              <p className="footer-office-phone">0120-216-921</p>
            </div>
            <div style={{ display: 'flex', gap: '20px' }}>
              <p className="footer-office-fax">TEL 048-958-6611</p>
              <p className="footer-office-fax">FAX 048-957-6140</p>
            </div>
            <button className="footer-office-button">
              シャーメゾン物件や居住用賃貸はこちら
            </button>
          </div>
          
          <div className="footer-office">
            <img 
              src="https://static.codia.ai/image/2026-01-14/m2Y6RK8mx7.png" 
              alt="駐車場案内" 
              className="footer-office-image"
            />
            <h3 className="footer-office-name">お客様駐車場のご案内</h3>
            <p className="footer-office-address">
              JR武蔵野線三郷駅北口 徒歩5分<br />
              本店となりにハウス２１専用<br />
              駐車場がございます。
            </p>
          </div>
          
          <div className="footer-office">
            <img 
              src="https://static.codia.ai/image/2026-01-14/Sc8oYBfQRA.png" 
              alt="IT不動産センター" 
              className="footer-office-image"
            />
            <h3 className="footer-office-name">IT不動産センター</h3>
            <p className="footer-office-address">埼玉県三郷市早稲田2-17-18</p>
            <p className="footer-office-phone">TEL 048-958-0221</p>
            <p className="footer-office-fax">FAX 048-957-6140</p>
            <button className="footer-office-button">
              事業用・売買・土地活用はこちら
            </button>
          </div>
        </div>
      </div>
      
      <div className="footer-bottom">
        <div className="footer-copyright">
          Copyright(c) house21 .All Rights Reserved.
        </div>
        <div className="footer-links">
          <a href="#" className="footer-link">サイトマップ</a>
          <a href="#" className="footer-link">サイトポリシー</a>
          <a href="#" className="footer-link">プライバシーポリシー</a>
        </div>
      </div>
    </footer>
  )
}

export default Footer
