import React from 'react'

const PropertyCategories = () => {
  const categories = [
    {
      icon: "https://static.codia.ai/image/2026-01-14/hmDp4yBkKa.png",
      title: "売却物件",
      description: "戸建・マンション・分譲地・\n収益物件を数多く揃えています！"
    },
    {
      icon: "https://static.codia.ai/image/2026-01-14/TnaepDU2Ds.png",
      title: "賃貸物件",
      description: "シャーメゾン物件やペット可物件\nなど数多く揃えています！"
    },
    {
      icon: "https://static.codia.ai/image/2026-01-14/ghBz85yi0g.png",
      title: "事業用物件",
      description: "貸地・店舗・事務所・倉庫などの\nお問い合わせはこちらから！"
    },
    {
      icon: "https://static.codia.ai/image/2026-01-14/BH4fimAVXo.png",
      title: "月極駐車場",
      description: "当社の空き駐車場情報は\nこちらから！"
    }
  ]

  return (
    <section className="property-categories">
      <div className="categories-grid">
        {categories.map((category, index) => (
          <React.Fragment key={index}>
            <div className="category-item">
              <img src={category.icon} alt={category.title} className="category-icon" />
              <h3 className="category-title">{category.title}</h3>
              <p className="category-description">{category.description}</p>
              <button className="category-button">詳細を見る</button>
            </div>
            {index < categories.length - 1 && <div className="category-divider"></div>}
          </React.Fragment>
        ))}
      </div>
    </section>
  )
}

export default PropertyCategories
