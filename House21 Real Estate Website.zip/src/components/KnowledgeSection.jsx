import React from 'react'

const KnowledgeSection = () => {
  const knowledgeItems = [
    {
      title: "住まいを借りる流れ",
      icon: "https://static.codia.ai/image/2026-01-14/7FqMuzE74D.png"
    },
    {
      title: "住まいを買う流れ",
      icon: "https://static.codia.ai/image/2026-01-14/uFKFA2fY7X.png"
    },
    {
      title: "売却について知る",
      icon: "https://static.codia.ai/image/2026-01-14/wa6xgCE7Sw.png"
    },
    {
      title: "賃貸経営について知る",
      icon: "https://static.codia.ai/image/2026-01-14/YBpvRMS1wK.png"
    }
  ]

  return (
    <section className="knowledge-section">
      <p className="knowledge-subtitle">Knowledge</p>
      <h2 className="knowledge-title">お役だちコラム</h2>
      
      <div className="knowledge-grid">
        {knowledgeItems.map((item, index) => (
          <div key={index} className="knowledge-card">
            <div style={{ marginBottom: '20px' }}>
              <img 
                src={item.icon} 
                alt={item.title} 
                style={{ width: '100px', height: '100px' }}
              />
            </div>
            <h3 className="knowledge-card-title">{item.title}</h3>
            <button className="knowledge-card-button">詳細を見る</button>
          </div>
        ))}
      </div>
    </section>
  )
}

export default KnowledgeSection
