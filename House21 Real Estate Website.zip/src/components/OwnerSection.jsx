import React from 'react'

const OwnerSection = () => {
  const services = [
    {
      title: "入居者様への各種対応",
      description: "入居ルールや各種告知などそして万一のときは、当社スタッフも近くにいるので駆けつけられます"
    },
    {
      title: "更新手続き対応",
      description: "たくさんの書面で面倒な更新手続きも当社が責任を持って実施いたします"
    },
    {
      title: "退去の対応",
      description: "解約処理から退去の立ち合いや清掃そして次の募集まで真心をこめて対応いたします"
    }
  ]

  return (
    <section className="owner-section">
      <h2 className="owner-title">物件をお持ちのオーナー様へ</h2>
      <p className="owner-subtitle">Lend</p>
      
      <div className="owner-content">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '60px', alignItems: 'center', marginBottom: '60px' }}>
          <div style={{ backgroundColor: '#125985', color: '#FFFFFF', padding: '40px', borderRadius: '20px' }}>
            <h3 style={{ fontSize: '20px', lineHeight: '27px', letterSpacing: '2px', marginBottom: '20px' }}>
              当社は埼玉県三郷市周辺で
            </h3>
            <h3 style={{ fontSize: '20px', lineHeight: '27px', letterSpacing: '2px', marginBottom: '20px' }}>
              賃貸アパートやマンションを含む
            </h3>
            <h3 style={{ fontSize: '20px', lineHeight: '27px', letterSpacing: '2px', marginBottom: '20px' }}>
              管理代行いたします。
            </h3>
            <p style={{ fontSize: '20px', lineHeight: '27px', letterSpacing: '2px', marginBottom: '20px' }}>
              賃貸経営には様々な業務がありますが、
            </p>
            <p style={{ fontSize: '20px', lineHeight: '27px', letterSpacing: '2px', marginBottom: '20px' }}>
              私たちは創業36年の経験と地域に
            </p>
            <p style={{ fontSize: '20px', lineHeight: '27px', letterSpacing: '2px', marginBottom: '20px' }}>
              密着したノウハウを活かし、
            </p>
            <p style={{ fontSize: '20px', lineHeight: '27px', letterSpacing: '2px', marginBottom: '20px' }}>
              あなたの大切な物件をしっかりと
            </p>
            <p style={{ fontSize: '20px', lineHeight: '27px', letterSpacing: '2px' }}>
              賃貸管理業務の代行を行っています。
            </p>
          </div>
          
          <div>
            <img 
              src="https://static.codia.ai/image/2026-01-14/ZQOrQXWfa9.png" 
              alt="ビジネス" 
              style={{ width: '366px', height: '269px' }}
            />
          </div>
        </div>
        
        <div style={{ backgroundColor: '#F5ECDB', borderRadius: '30px', padding: '40px', marginBottom: '60px' }}>
          <h3 style={{ fontSize: '35px', lineHeight: '57px', letterSpacing: '10.5px', color: '#125985', textAlign: 'center', marginBottom: '40px' }}>
            不動産オーナー様の<br />こんなご相談を多く承っております。
          </h3>
          
          <div style={{ textAlign: 'center', marginBottom: '40px' }}>
            <img 
              src="https://static.codia.ai/image/2026-01-14/Kt3zv5tcAL.png" 
              alt="困った" 
              style={{ width: '379px', height: '304px' }}
            />
          </div>
          
          <div style={{ textAlign: 'center' }}>
            <button className="category-button" style={{ fontSize: '18px', padding: '15px 40px' }}>
              お悩みの方はご相談ください
            </button>
          </div>
        </div>
        
        <h3 style={{ fontSize: '40px', lineHeight: '70px', letterSpacing: '8px', color: '#125985', marginBottom: '40px' }}>
          入居後の管理も<br />ご安心ください
        </h3>
        
        <div className="owner-services-grid">
          {services.map((service, index) => (
            <div key={index} className="owner-service">
              <div className="owner-service-image"></div>
              <p className="owner-service-description">{service.description}</p>
            </div>
          ))}
        </div>
        
        <div style={{ textAlign: 'center', marginTop: '40px' }}>
          <button className="category-button" style={{ fontSize: '18px', padding: '15px 40px' }}>
            まずはお問い合わせください
          </button>
        </div>
      </div>
    </section>
  )
}

export default OwnerSection
