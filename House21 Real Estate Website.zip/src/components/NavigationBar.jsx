import React from 'react'

const NavigationBar = () => {
  return (
    <nav className="nav-bar">
      <a href="#" className="nav-item">物件検索</a>
      <div className="nav-divider"></div>
      <a href="#" className="nav-item">売却相談</a>
      <div className="nav-divider"></div>
      <a href="#" className="nav-item">オーナー様</a>
      <div className="nav-divider"></div>
      <a href="#" className="nav-item">入居者様</a>
      <div className="nav-divider"></div>
      <a href="#" className="nav-item">ブログ</a>
      <div className="nav-divider"></div>
      <a href="#" className="nav-item">会社概要</a>
    </nav>
  )
}

export default NavigationBar
