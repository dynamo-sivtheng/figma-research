import React from 'react'

const Header = () => {
  return (
    <header className="header">
      <div className="header-content">
        <div className="logo-section">
          <img 
            src="https://static.codia.ai/image/2026-01-14/8MP5GcRQm2.png" 
            alt="ハウストゥエンティーワン ロゴ" 
            className="logo"
          />
          <h1 className="company-name">株式会社ハウストゥエンティーワン</h1>
        </div>
        
        <nav className="nav-section">
          <div className="nav-links">
            <a href="#" className="nav-link">物件検索</a>
            <a href="#" className="nav-link">売却相談</a>
            <a href="#" className="nav-link">オーナー様</a>
            <a href="#" className="nav-link">入居者様</a>
            <a href="#" className="nav-link">ブログ</a>
            <a href="#" className="nav-link">会社概要</a>
          </div>
          
          <div className="phone-section">
            <img 
              src="https://static.codia.ai/image/2026-01-14/rF6tTnzAN9.png" 
              alt="FREE" 
              className="free-icon"
            />
            <span className="phone-number">0120-216-921</span>
          </div>
          
          <button className="line-button">
            <img 
              src="https://static.codia.ai/image/2026-01-14/BkZYbyK8B7.png" 
              alt="LINE" 
              className="line-icon"
            />
            <span className="line-text">LINEから<br />お問い合わせ！</span>
          </button>
          
          <button className="contact-button">
            <span className="contact-text">お問い合わせ<br />来店予約</span>
          </button>
        </nav>
      </div>
    </header>
  )
}

export default Header
