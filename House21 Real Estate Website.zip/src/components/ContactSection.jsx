import React from 'react'

const ContactSection = () => {
  return (
    <section className="contact-section">
      <p className="contact-subtitle">Contact</p>
      <h2 className="contact-title">お問い合わせ</h2>
      <p className="contact-description">
        メール・電話・お問い合わせフォームいずれの方法でもどうぞお気軽にお問い合わせください！
      </p>
      
      <div className="contact-methods">
        <div className="contact-method">
          <img 
            src="https://static.codia.ai/image/2026-01-14/eJGrZX60Cv.png" 
            alt="メール" 
            className="contact-method-icon"
          />
          <p className="contact-method-title">
            代表メールアドレス<br />
            mail@house21net.co.jp
          </p>
        </div>
        
        <div className="contact-method">
          <div style={{ width: '194px', height: '167px', margin: '0 auto 20px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ fontSize: '60px', color: '#125985' }}>📞</div>
          </div>
          <p className="contact-method-title">
            フォームから<br />
            お問い合わせ・来店予約
          </p>
        </div>
        
        <div className="contact-method">
          <div style={{ width: '194px', height: '167px', margin: '0 auto 20px', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#FDD23E', borderRadius: '50%' }}>
            <div style={{ fontSize: '60px', color: '#000' }}>📱</div>
          </div>
          <p className="contact-method-title">LINEからお問い合わせ！</p>
        </div>
      </div>
      
      <div className="contact-hours">
        営業時間：9:00～17:30　｜　定休日：火曜日・水曜日定休
      </div>
    </section>
  )
}

export default ContactSection
