import React from 'react'

const SellSection = () => {
  const reasons = [
    {
      image: "https://static.codia.ai/image/2026-01-14/JLo6H7Ny7A.png",
      title: "不動産に新たな価値提供を",
      description: "不動産は工夫することで付加価値を付け、より魅力的なものへと変身します。私たちは豊富な実績と経験を活かし、お客様の悩みや気持ちに寄り添いながら、周辺環境や現状を的確に分析し、個々のニーズに合った提案で、物件に新しい価値を創造していきます。"
    },
    {
      image: "https://static.codia.ai/image/2026-01-14/oQwJBKvYA1.png",
      title: "お客様の立場に立ったスピード感",
      description: "不動産取引において、スピード感は欠かせません。お客様の「早急に解決したい」「急いで売買を進めたい」という思いに寄り添い、お客様の立場に立ったスピーディな対応と安心感を提供します。不動産の売却・買取のご相談はハウストゥエンティーワンにお任せください。"
    },
    {
      image: "https://static.codia.ai/image/2026-01-14/D0M5eBQWjZ.png",
      title: "買取・仲介のどちらにも精通",
      description: "当社は不動産の「買取・仲介」業を行っており、売却者・購入者・仲介者それぞれの気持ちを理解しています。メリット・デメリットに精通し、物件の魅力を最大限引き出すことで付加価値を提供します。また、賃貸業や専門の税理士・弁護士との連携も行っております。"
    }
  ]

  const cases = [
    {
      image: "https://static.codia.ai/image/2026-01-14/jzzObM9ASR.png",
      title: "任意売却",
      description: "ローンのお支払いに困った時に\n秘密厳守で対応いたします"
    },
    {
      image: "https://static.codia.ai/image/2026-01-14/NiG3oOzFee.png",
      title: "住み替え・買い替え",
      description: "新しい住まいに\n住み替える際の売却について"
    },
    {
      image: "https://static.codia.ai/image/2026-01-14/mDPRAWX777.png",
      title: "相続した不動産の処分",
      description: "もしもの時に、もしもの前に\nご相談ください"
    },
    {
      image: "https://static.codia.ai/image/2026-01-14/Z9TP6UURYA.png",
      title: "扱いに困っている不動産",
      description: "固定資産税などの\nコストに困っていませんか？"
    }
  ]

  return (
    <section className="sell-section">
      <h2 className="sell-title">売却をご検討の方へ</h2>
      <p className="sell-subtitle">Sell</p>
      
      <div className="sell-content">
        <h3 className="sell-reasons-title">当社が<br />選ばれる理由</h3>
        <p style={{ fontSize: '18px', lineHeight: '40px', letterSpacing: '1.8px', marginBottom: '40px' }}>
          地元三郷市に根差して36年。<br />
          ハウストゥエンティーワンが<br />
          選ばれているのには理由があります。
        </p>
        
        <div className="sell-reasons-grid">
          {reasons.map((reason, index) => (
            <div key={index} className="sell-reason">
              <img src={reason.image} alt={reason.title} className="sell-reason-image" />
              <p className="sell-reason-description">{reason.description}</p>
            </div>
          ))}
        </div>
        
        <h3 className="sell-cases-title">売却ケース</h3>
        <p style={{ fontSize: '18px', lineHeight: '40px', letterSpacing: '1.8px', marginBottom: '40px' }}>
          これまでの当社の実績や経験から、<br />
          よくあるケースごと解決方法を<br />
          ご紹介します。
        </p>
        
        <div className="sell-cases-grid">
          {cases.map((caseItem, index) => (
            <div key={index} className="sell-case">
              <img src={caseItem.image} alt={caseItem.title} className="sell-case-image" />
              <h4 className="sell-case-title">{caseItem.title}</h4>
              <p className="sell-case-description">{caseItem.description}</p>
              <button className="sell-case-button">詳細を見る</button>
            </div>
          ))}
        </div>
        
        <div style={{ textAlign: 'center', marginTop: '40px' }}>
          <button className="sell-case-button" style={{ fontSize: '18px', padding: '15px 40px' }}>
            まずは調査依頼する
          </button>
        </div>
      </div>
    </section>
  )
}

export default SellSection
