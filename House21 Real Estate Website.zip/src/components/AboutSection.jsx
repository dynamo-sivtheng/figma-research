import React from 'react'

const AboutSection = () => {
  return (
    <section className="about-section">
      <p className="about-subtitle">About Us</p>
      <h2 className="about-title">ハウストゥエンティーワンについて</h2>
      
      <div className="about-content">
        <div className="about-text">
          <h3 className="about-company-title">『ハウストゥエンティーワン』とは</h3>
          <p className="about-company-description">
            三郷市の不動産会社「株式会社ハウストゥエンティーワン」は、
          </p>
          <p className="about-company-description">
            昭和62年の創業以来36年にわたり、地域密着の不動産会社として営業を続けております。
          </p>
          <p className="about-company-description">
            ありがたいことに現在まで多くのお客様にご愛顧いただいております。
          </p>
        </div>
        
        <div className="about-mission">
          <h3 className="about-mission-title">より良い<br />お住まいを<br />見つける為に</h3>
          <p className="about-mission-text">
            住まい探しは楽しいものですが、わからないことだらけで<br />
            不安を感じたり、不動産会社への相談はまだ早いかなと躊躇しているお客様はいらっしゃいませんか？不動産選びは人生の大きな一歩ですから、ご不安もあるかと思います。<br />
            私たちが全力を尽くしてサポート致しますので、是非一度物件を見てみませんか？<br />
            広告や図面から知識を得ることもできますが、実際に現地を訪れることで、そのお住まいでの生活をより鮮明にイメージできたり、物件の長所と短所を見極める力も養われます。最適なお住まいを見つけるために、まずは私たちが物件をご案内させて頂きます！お客様の不安をスタッフが全て解消し、住まい探しを存分に楽しんでいただけるようサポートさせて頂きます！
          </p>
        </div>
      </div>
      
      <div style={{ textAlign: 'center', marginTop: '40px' }}>
        <button className="category-button" style={{ fontSize: '18px', padding: '15px 40px' }}>
          会社紹介
        </button>
      </div>
    </section>
  )
}

export default AboutSection
