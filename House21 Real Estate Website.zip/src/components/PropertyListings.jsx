import React from 'react'

const PropertyListings = () => {
  const sellProperties = [
    {
      image: "https://static.codia.ai/image/2026-01-14/6QjkdLnFmD.png",
      price: "99,999",
      type: "3LDK",
      details: "土地面積 - 999.99㎡ / 建物面積 - 999.99㎡",
      location: "三郷市上口１丁目",
      station: "つくばエクスプレス / 三郷中央駅 徒歩13分",
      category: "売戸建住宅"
    },
    {
      image: "https://static.codia.ai/image/2026-01-14/6QjkdLnFmD.png",
      price: "99,999",
      type: "3LDK",
      details: "土地面積 - 999.99㎡ / 建物面積 - 999.99㎡",
      location: "三郷市上口１丁目",
      station: "つくばエクスプレス / 三郷中央駅 徒歩13分",
      category: "売戸建住宅"
    },
    {
      image: "https://static.codia.ai/image/2026-01-14/6QjkdLnFmD.png",
      price: "99,999",
      type: "3LDK",
      details: "土地面積 - 999.99㎡ / 建物面積 - 999.99㎡",
      location: "三郷市上口１丁目",
      station: "つくばエクスプレス / 三郷中央駅 徒歩13分",
      category: "売戸建住宅"
    }
  ]

  const rentProperties = [
    {
      image: "https://static.codia.ai/image/2026-01-14/6QjkdLnFmD.png",
      price: "99,9",
      name: "物件名物件名物件名物件名...",
      details: "敷金 - 1ヶ月 / 礼金 - 1ヶ月 / 面積 - 999.99㎡",
      location: "三郷市上口１丁目",
      station: "つくばエクスプレス / 三郷中央駅 徒歩13分"
    },
    {
      image: "https://static.codia.ai/image/2026-01-14/6QjkdLnFmD.png",
      price: "99,9",
      name: "物件名物件名物件名物件名...",
      details: "敷金 - 1ヶ月 / 礼金 - 1ヶ月 / 面積 - 999.99㎡",
      location: "三郷市上口１丁目",
      station: "つくばエクスプレス / 三郷中央駅 徒歩13分"
    },
    {
      image: "https://static.codia.ai/image/2026-01-14/6QjkdLnFmD.png",
      price: "99,9",
      name: "物件名物件名物件名物件名...",
      details: "敷金 - 1ヶ月 / 礼金 - 1ヶ月 / 面積 - 999.99㎡",
      location: "三郷市上口１丁目",
      station: "つくばエクスプレス / 三郷中央駅 徒歩13分"
    }
  ]

  return (
    <section className="property-section">
      {/* Sell Properties */}
      <div style={{ marginBottom: '80px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '40px' }}>
          <img 
            src="https://static.codia.ai/image/2026-01-14/hmDp4yBkKa.png" 
            alt="売却物件" 
            style={{ width: '250px', height: '188px', marginRight: '40px' }}
          />
          <div>
            <h2 className="section-title">おすすめ売却物件</h2>
            <button className="category-button" style={{ marginTop: '20px' }}>
              売買物件一覧を見る
            </button>
          </div>
        </div>
        
        <div className="property-grid">
          {sellProperties.map((property, index) => (
            <div key={index} className="property-card">
              <div style={{ position: 'relative' }}>
                <img src={property.image} alt="物件画像" className="property-image" />
                <span className="new-badge">NEW</span>
              </div>
              <div className="property-info">
                <div style={{ backgroundColor: '#EADCD1', padding: '5px', borderRadius: '4px', marginBottom: '10px' }}>
                  <span style={{ fontSize: '10px', color: '#3B4043' }}>{property.category}</span>
                </div>
                <div style={{ fontSize: '10px', color: '#424242', fontWeight: '800', marginBottom: '10px' }}>
                  {property.type}
                </div>
                <div className="property-price">
                  {property.price}<span className="property-price-unit">万円</span>
                </div>
                <div className="property-details">{property.details}</div>
                <div className="property-location">{property.location}</div>
                <div className="property-station">{property.station}</div>
                <button className="property-button">詳細を見る</button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Rent Properties */}
      <div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '40px' }}>
          <img 
            src="https://static.codia.ai/image/2026-01-14/7fAMQdrFh4.png" 
            alt="賃貸物件" 
            style={{ width: '250px', height: '196px', marginRight: '40px' }}
          />
          <div>
            <h2 className="section-title">おすすめ賃貸物件</h2>
            <button className="category-button" style={{ marginTop: '20px' }}>
              賃貸物件一覧を見る
            </button>
          </div>
        </div>
        
        <div className="property-grid">
          {rentProperties.map((property, index) => (
            <div key={index} className="property-card">
              <div style={{ position: 'relative' }}>
                <img src={property.image} alt="物件画像" className="property-image" />
                <span className="new-badge">NEW</span>
              </div>
              <div className="property-info">
                <div className="property-name">{property.name}</div>
                <div className="property-price">
                  {property.price}<span className="property-price-unit">万円</span>
                </div>
                <div className="property-details">{property.details}</div>
                <div className="property-location">{property.location}</div>
                <div className="property-station">{property.station}</div>
                <button className="property-button">詳細を見る</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default PropertyListings
