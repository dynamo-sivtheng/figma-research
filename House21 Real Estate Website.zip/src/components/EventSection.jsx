import React from 'react'

const EventSection = () => {
  return (
    <section className="event-section">
      <div style={{ textAlign: 'center', marginBottom: '40px' }}>
        <div className="event-title">新築分譲</div>
        <div className="event-title">現地販売会</div>
        <div className="event-subtitle">随時<br />開催中</div>
      </div>
      
      <div className="event-description">ぜひ現地でご覧になってください！</div>
      <div className="event-description">皆様のご来場お待ちしております。</div>
      
      <div style={{ marginTop: '40px' }}>
        <button className="event-button">イベント情報を見る</button>
      </div>
      
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '60px' }}>
        <img 
          src="https://static.codia.ai/image/2026-01-14/EWmZV8oSRn.png" 
          alt="家族1" 
          style={{ width: '274px', height: '224px' }}
        />
        <img 
          src="https://static.codia.ai/image/2026-01-14/5uCJDErkKX.png" 
          alt="建物" 
          style={{ width: '600px', height: '415px' }}
        />
        <img 
          src="https://static.codia.ai/image/2026-01-14/UZsBRj1kPV.png" 
          alt="家族2" 
          style={{ width: '294px', height: '224px' }}
        />
      </div>
    </section>
  )
}

export default EventSection
