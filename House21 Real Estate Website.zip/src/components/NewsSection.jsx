import React from 'react'

const NewsSection = () => {
  const newsItems = [
    {
      date: "2024.00.00",
      category: "お知らせ",
      title: "お知らせタイトルお知らせタイトル...",
      image: "https://static.codia.ai/image/2026-01-14/4zTLGHTDfm.png"
    },
    {
      date: "2024.00.00",
      category: "新着物件",
      title: "お知らせタイトルお知らせタイトル...",
      image: "https://static.codia.ai/image/2026-01-14/nfajQPPBvE.png"
    },
    {
      date: "2024.00.00",
      category: "ブログ",
      title: "お知らせタイトルお知らせタイトル...",
      image: "https://static.codia.ai/image/2026-01-14/Snk5Hg2Z4s.png"
    },
    {
      date: "2024.00.00",
      category: "イベント",
      title: "お知らせタイトルお知らせタイトル...",
      image: "https://static.codia.ai/image/2026-01-14/ar6cEwWG6m.png"
    }
  ]

  return (
    <section className="news-section">
      <p className="news-subtitle">News & Info</p>
      <h2 className="news-title">お知らせ・新着物件</h2>
      
      <div className="news-grid">
        {newsItems.map((item, index) => (
          <div key={index} className="news-card">
            <div style={{ position: 'relative' }}>
              <span className="new-badge">NEW</span>
              <img src={item.image} alt={item.title} className="news-card-image" />
            </div>
            <div className="news-card-content">
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px' }}>
                <span className="news-card-date">{item.date}</span>
                <span className="news-card-category">{item.category}</span>
              </div>
              <h3 className="news-card-title">{item.title}</h3>
              <button className="news-card-button">詳細を見る</button>
            </div>
          </div>
        ))}
      </div>
      
      <div style={{ textAlign: 'center', marginTop: '40px' }}>
        <button className="category-button" style={{ fontSize: '18px', padding: '15px 40px' }}>
          お知らせ一覧
        </button>
      </div>
    </section>
  )
}

export default NewsSection
