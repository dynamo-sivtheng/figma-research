import React from 'react'

const BlogSection = () => {
  const blogItems = [
    "2024.00.00　ゴールデンウィーク休業のお知らせ",
    "2024.00.00　ブログ記事タイトルがはいります。ブログ記事タイトルがはいります。ブログ記事タイトルがはいります。",
    "2024.00.00　ブログ記事タイトルがはいります。ブログ記事タイトルがはいります。ブログ記事タイトルがはいります。",
    "2024.00.00　ブログ記事タイトルがはいります。ブログ記事タイトルがはいります。ブログ記事タイトルがはいります。"
  ]

  return (
    <section className="blog-section">
      <p className="blog-subtitle">Blog</p>
      <h2 className="blog-title">三郷市賃貸アパートブログ</h2>
      
      <div className="blog-list">
        {blogItems.map((item, index) => (
          <div key={index} className="blog-item">
            <div className="blog-item-content">
              <span className="blog-date">{item.substring(0, 10)}</span>
              <span>{item.substring(10)}</span>
            </div>
          </div>
        ))}
      </div>
      
      <div style={{ textAlign: 'center', marginTop: '40px' }}>
        <button className="category-button" style={{ fontSize: '18px', padding: '15px 40px' }}>
          三郷市賃貸アパートブログ一覧
        </button>
      </div>
    </section>
  )
}

export default BlogSection
