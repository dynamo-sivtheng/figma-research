import React from 'react'

const HeroSection = () => {
  return (
    <section className="hero-section">
      <div className="hero-content">
        <div style={{ position: 'relative', display: 'inline-block' }}>
          <div className="hero-subtitle">お部屋<br />探しは</div>
          <div className="hero-highlight" style={{ position: 'absolute', top: '20px', left: '0', width: '104px', height: '22px' }}></div>
          <div className="hero-highlight" style={{ position: 'absolute', top: '66px', left: '0', width: '104px', height: '22px' }}></div>
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '20px', marginTop: '40px' }}>
          <span className="hero-large-text">冒</span>
          <span className="hero-extra-large-text">険</span>
          <span style={{ fontSize: '114px', lineHeight: '45px', letterSpacing: '-22.8px' }}>だ！</span>
        </div>
        
        <div className="hero-description">
          楽しくお部屋探しをするなら<br />
          <span style={{ color: '#333333' }}>ハウストゥエンティーワン</span>
        </div>
        
        <div style={{ marginTop: '40px', textAlign: 'right' }}>
          <span style={{ fontSize: '22px', lineHeight: '44px', letterSpacing: '2.2px' }}>私たちと一緒に！</span>
        </div>
      </div>
    </section>
  )
}

export default HeroSection
