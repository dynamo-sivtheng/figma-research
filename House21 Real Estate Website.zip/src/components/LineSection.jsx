import React from 'react'

const LineSection = () => {
  return (
    <section className="line-section">
      <h2 className="line-title">LINE公式アカウント</h2>
      <p className="line-subtitle">気軽にLINEからもご相談ください。</p>
      <p className="line-description">ハウス21公式LINEからも物件のお問い合わせ可能！</p>
      
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '40px' }}>
        <div style={{ textAlign: 'center' }}>
          <img 
            src="https://static.codia.ai/image/2026-01-14/9CycCD4ZSM.png" 
            alt="LINE QRコード" 
            className="line-qr"
          />
          <p className="line-cta">今すぐ友だち追加！</p>
        </div>
      </div>
    </section>
  )
}

export default LineSection
